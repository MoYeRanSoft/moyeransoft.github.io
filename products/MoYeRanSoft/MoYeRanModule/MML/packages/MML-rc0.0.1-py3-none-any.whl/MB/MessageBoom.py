from time import sleep

from pyautogui import hotkey
from pynput.keyboard import Controller


class MessageBoom:
    def __init__(
            self,
            key,
            Sign=None
    ):
        r"""
            __  ___  __  __     ____              __  ___                                ____
           /  |/  /__\ \/ /__  / __ \____ _____  /  |/  /__  ______________ _____ ____  / __ )____  ____  ____ ___
          / /|_/ / __ \  / _ \/ /_/ / __ `/ __ \/ /|_/ / _ \/ ___/ ___/ __ `/ __ `/ _ \/ __  / __ \/ __ \/ __ `__ \
         / /  / / /_/ / /  __/ _, _/ /_/ / / / / /  / /  __(__  |__  ) /_/ / /_/ /  __/ /_/ / /_/ / /_/ / / / / / /
        /_/  /_/\____/_/\___/_/ |_|\__,_/_/ /_/_/  /_/\___/____/____/\__,_/\__, /\___/_____/\____/\____/_/ /_/ /_/
                                                                          /____/

        Parameters:

            key(list[str]):
                The key which can send message.
            Sign(str):
                Sign.
        """
        self.key = key
        if Sign is None:
            self.Sign = 'Nothing'
        else:
            self.Sign = Sign
        self.control = Controller()

    def repeat(
            self,
            message: str,
            quantity: int = 1,
            wait: int = 10,
            speed: float = 0,
            indexShow: bool = False
    ):
        """
        Send repeated message.

        Parameters:

            message(str):
                The message to send.
            quantity(int):
                The quantity of the message.
            wait(int):
                The time wait for going to the chat window.
            speed(float):
                The speed of the message.
            indexShow(bool):
                Whether to show the index of the message.

        Example:
            MessageBoom(
                key=['enter']
            ).repeat(
                message='TEST',
                quantity=20,
                wait=10,
                speed=1,
                indexShow=True
            )
        """
        print(f'You have {wait} seconds to goto the chat window.')
        print('message', '=', message)
        print('speed', '=', speed, 'seconds')
        print('Good Luck!')
        sleep(wait)
        for i in range(quantity):
            self.control.type(
                message + '[' + str(
                    {
                        True: i,
                        False: ''
                    }[indexShow]
                ) + ']'
            )
            hotkey(*self.key)
            sleep(speed)

    def send(
            self,
            message: str,
            wait: int = 10,
    ):
        """
        Send one message.

        Parameters:

            message(str):
                The message to send.
            wait(int):
                The time wait for going to the chat window.

        Example:
            MessageBoom(
                key=['enter']
            ).send(
                message='TEST',
                wait=10,
            )
        """
        print(f'You have {wait} seconds to goto the chat window.')
        print('message', '=', message)
        print('Good Luck!')
        sleep(wait)
        self.control.type(message)
        hotkey(*self.key)

    def sends(
            self,
            messages: list,
            wait: int = 10,
            speed: float = 0
    ):
        """
        Send repeated message.

        Parameters:

            messages(list):
                The list of messages to send.
            wait(int):
                The time wait for going to the chat window.
            speed(float):
                The speed of the message.

        Example:
            MessageBoom(
                key=['enter']
            ).repeat(
                messages=['TEST one', 'TEST two', 'TEST three'],
                wait=10,
                speed=1
            )
        """
        print(f'You have {wait} seconds to goto the chat window.')
        print('messages', '=', messages)
        print('speed', '=', speed, 'seconds')
        print('Good Luck!')
        sleep(wait)
        for message in messages:
            self.control.type(message)
            hotkey(*self.key)
            sleep(speed)


if __name__ == '__main__':
    MessageBoom(['ctrl', 'enter']).repeat('测试', 20, speed=1, indexShow=True)
    MessageBoom(['ctrl', 'enter']).send('测试', )
    MessageBoom(['ctrl', 'enter']).sends(['测试1', '测试2', '测试3'], speed=1)
